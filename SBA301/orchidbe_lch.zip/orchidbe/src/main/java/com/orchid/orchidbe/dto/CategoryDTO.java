package com.orchid.orchidbe.dto;

public interface CategoryDTO {

    record CategoryReq(
        String name
    ){

    }

}
