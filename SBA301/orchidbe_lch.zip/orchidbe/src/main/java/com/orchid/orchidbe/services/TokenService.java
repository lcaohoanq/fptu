package com.orchid.orchidbe.services;

import com.orchid.orchidbe.pojos.Account;
import com.orchid.orchidbe.pojos.Token;
import org.bson.types.ObjectId;

public interface TokenService {

    Token addToken(String userId, String token, boolean isMobileDevice);

    Token refreshToken(String refreshToken, Account user) throws Exception;

    void deleteToken(String token, Account user);

    Token findAccountByToken(String token);

}
