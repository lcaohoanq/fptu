package com.orchid.orchidbe.controllers;

import com.orchid.orchidbe.apis.MyApiResponse;
import com.orchid.orchidbe.dto.AccountDTO;
import com.orchid.orchidbe.pojos.Account;
import com.orchid.orchidbe.services.AccountService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${api.prefix}/accounts")
@RequiredArgsConstructor
@Tag(name = "accounts", description = "Operation related to Account")
@Slf4j
public class AccountController {

    private final AccountService accountService;

    @GetMapping("")
    @Operation(summary = "Get all accounts", description = "Returns a list of all accounts")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved all accounts")
    public ResponseEntity<MyApiResponse<List<AccountDTO.AccountResp>>> getAccounts() {
        return MyApiResponse.success(accountService.getAll());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get all accounts", description = "Returns a list of all accounts")
    @ApiResponse(responseCode = "200", description = "Successfully retrieved all accounts")
    public ResponseEntity<MyApiResponse<Account>> getAccountById(@PathVariable String id) {
        return MyApiResponse.success(accountService.getById(id));
    }

    //Get user details from token
    @GetMapping("/me")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_USER', 'ROLE_STAFF')")
    public ResponseEntity<MyApiResponse<Account>> getUserDetails(HttpServletRequest request)
        throws Exception {
        String token = request.getHeader("Authorization");
        if (token == null || !token.startsWith("Bearer ")) {
            return MyApiResponse.unauthorized("Missing or invalid Authorization header");
        }
        token = token.substring(7); // Remove "Bearer " prefix
        Account userDetail = accountService.getUserDetailsFromToken(token);
        return MyApiResponse.success(userDetail);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update account", description = "Updates an existing account by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Account updated successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input or email already exists"),
        @ApiResponse(responseCode = "404", description = "Account not found")
    })
    public ResponseEntity<MyApiResponse<Object>> updateAccount(
        @PathVariable String id,
        @RequestBody AccountDTO.UpdateAccountReq accountReq
    ) {
        accountService.update(id, accountReq);
        return MyApiResponse.updated();
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete account", description = "Deletes an account by ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Account deleted successfully"),
        @ApiResponse(responseCode = "404", description = "Account not found")
    })
    public ResponseEntity<MyApiResponse<Object>> deleteAccount(@PathVariable String id) {
        accountService.delete(id);
        return MyApiResponse.noContent();
    }

}
